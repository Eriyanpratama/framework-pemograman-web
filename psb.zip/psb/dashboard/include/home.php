<h2>Selamat Datang, <?php $role == "Admin" ?  print($nama_admin) : print($nama); ?></h2>

